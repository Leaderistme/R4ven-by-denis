"""
Purpose: will hold the pydentic data
"""
from pydantic import BaseModel

